# VT1
Github for the VT1 Project

1. Insert callibration image into Png2Ply\Insert_Images
2. Run Calibration.ipynb to construct calibration matrix of the pipe
3. Delete callibration image and insert scanning image into Png2Ply\Insert_Images
4. Run MainCode.ipynb to output distance, angle, ovality and curvature plot.
5. Remember to delete old pictures before trying 1. again. Everything else takes care of itself. 
If callibration isnt needet start from step 3, and remember to delete callibration matrix if it isnt used. When generating new callibration matrix it automatically deletes the old one.
